package packt.book.jee.eclipse.ch4.jpa.bean;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-03-11T15:44:16.476+0530")
@StaticMetamodel(Teacher.class)
public class Teacher_ extends Person_ {
	public static volatile SingularAttribute<Teacher, String> designation;
}
