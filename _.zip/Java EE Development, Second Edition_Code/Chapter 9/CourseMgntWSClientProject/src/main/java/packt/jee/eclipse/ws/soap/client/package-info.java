@javax.xml.bind.annotation.XmlSchema(namespace = "http://soap.ws.eclipse.jee.packt/")
package packt.jee.eclipse.ws.soap.client;
