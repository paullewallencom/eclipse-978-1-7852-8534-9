package packt.jee.eclipse.spring;

import org.springframework.stereotype.Component;

public interface ICourseDAO {

}
